import React, { useEffect, useState } from 'react'
import { supabase } from './lib/supabaseClient'

const App = () => {
  const [user, setUser] = useState<any>(null)
  const [tema, setTema] = useState('')
  const [roteiro, setRoteiro] = useState('')
  const [creditos, setCreditos] = useState<number | null>(null)

  useEffect(() => {
    supabase.auth.getUser().then(({ data: { user } }) => {
      setUser(user)
      if (user) fetchCredits(user.id)
    })

    const { data: authListener } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user || null)
      if (session?.user) fetchCredits(session.user.id)
    })

    return () => authListener.subscription.unsubscribe()
  }, [])

  const fetchCredits = async (userId: string) => {
    const { data } = await supabase.from('profiles').select('credits').eq('id', userId).single()
    setCreditos(data?.credits ?? 0)
  }

  const handleLogin = async () => {
    await supabase.auth.signInWithOAuth({ provider: 'google' })
  }

  const handleLogout = async () => {
    await supabase.auth.signOut()
    setUser(null)
    setCreditos(null)
  }

  const gerarRoteiro = async () => {
    if (!tema.trim() || !user || creditos === null || creditos <= 0) return

    const roteiroSimulado = `1. Hook: "Sabia que você pode ganhar R$200 por dia usando IA?"\n2. Autoridade: "Faço isso todo dia usando o Editoria Turbo."\n3. Explicação: "Basta digitar o tema e pronto."\n4. CTA: "Teste agora. Link na bio."`
    setRoteiro(roteiroSimulado)
    setCreditos(creditos - 1)

    await supabase.from('profiles').update({ credits: creditos - 1 }).eq('id', user.id)
  }

  if (!user) {
    return (
      <div className="min-h-screen flex flex-col justify-center items-center bg-[#0F1325] text-white px-4">
        <h1 className="text-3xl font-bold text-cyan-400 mb-4">Editoria Turbo 🚀</h1>
        <p className="text-white/70 mb-6 text-center">Seu assistente criativo para roteiros de TikTok e Reels</p>
        <button onClick={handleLogin} className="bg-purple-500 px-6 py-3 rounded text-white hover:bg-purple-600 transition">Entrar com Google</button>
      </div>
    )
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-start bg-[#0F1325] text-white px-4 py-10">
      <h2 className="text-xl font-bold mb-4">Bem-vindo, {user.email}</h2>
      <p className="mb-2 text-cyan-400">Créditos restantes: {creditos}</p>

      <input
        value={tema}
        onChange={(e) => setTema(e.target.value)}
        placeholder="Digite o tema do vídeo"
        className="mb-4 w-full max-w-md px-4 py-2 rounded bg-white/10 placeholder-white/60 border border-purple-400"
      />

      <button
        onClick={gerarRoteiro}
        disabled={creditos === 0}
        className="mb-6 bg-gradient-to-r from-purple-500 to-cyan-500 px-6 py-3 rounded text-white hover:from-cyan-500 hover:to-purple-500 disabled:opacity-50"
      >
        Gerar roteiro
      </button>

      {creditos === 0 && (
        <div className="text-center mb-4">
          <p className="text-red-400 font-bold mb-2">Créditos esgotados!</p>
          <a
            href="https://pay.kiwify.com.br/BOhScFj"
            target="_blank"
            className="bg-purple-600 px-6 py-3 rounded text-white hover:bg-purple-700"
          >
            💳 Comprar 30 créditos por R$ 19,90
          </a>
        </div>
      )}

      {roteiro && (
        <pre className="bg-[#1A1F3A] p-4 rounded max-w-md whitespace-pre-wrap">{roteiro}</pre>
      )}

      <button onClick={handleLogout} className="mt-6 text-sm text-white/40 hover:text-white">Sair</button>
    </div>
  )
}

export default App
